package com.project.workmandroid;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class CheckContractActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_contract);

    }
}
