package com.project.workmandroid;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import android.util.Log;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

import com.project.workmandroid.CheckContractActivity;
import com.project.workmandroid.R;
import com.project.workmandroid.SignatureActivity;

public class EmployerMainActivity extends AppCompatActivity {
    private Button mSign;
    private Button mCheck;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employer_main);

        Button mSign = findViewById(R.id.mSign);
        Button mCheck = findViewById(R.id.mCheck);

        //use cookie
        SharedPreferences sf = getSharedPreferences("sFile",MODE_PRIVATE);
        String getUserid = sf.getString("userid","nop");
        Log.e("main",getUserid);

        mSign.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(EmployerMainActivity.this, SignatureActivity.class);
                startActivity(intent);
            }
        });

        mCheck.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(EmployerMainActivity.this, CheckContractActivity.class);
                startActivity(intent);
            }
        });
    }
}